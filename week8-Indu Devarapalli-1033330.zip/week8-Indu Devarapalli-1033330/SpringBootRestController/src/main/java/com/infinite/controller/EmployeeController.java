package com.infinite.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.model.Employee;
import com.infinite.service.EmployeeService;
@RestController
@RequestMapping(value = "/rest")
public class EmployeeController {
		@Autowired
		EmployeeService employeeService;
		@RequestMapping(value="/employees", method=RequestMethod.POST)
		public Employee createEmployee(@RequestBody Employee emp) {
			System.out.println("creation of table employee ");
		    return employeeService.createEmployee(emp);
		}
		@RequestMapping(value = "/reademployees", method = RequestMethod.GET)
		public List<Employee> readEmployees() {
			System.out.println("read of table employee ");
			return employeeService.getEmployees();
		}
		
}
